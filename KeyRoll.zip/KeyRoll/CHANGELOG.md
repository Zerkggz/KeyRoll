## Version 3.0.0 - Midnight Update

### Major Changes
- **Midnight Beta Support**: Updated for World of Warcraft: Midnight expansion
- **Complete Code Restructure**: Split monolithic file into modular architecture (Keyroll.lua, Utils.lua, Capture.lua, Comm.lua, Dungeons.lua)
- **Modern API Migration**: Switched from deprecated bag API to C_Container API
- **Expansion-Proof Detection**: Changed from item ID-based to text-based keystone detection

### New Features
- **GUI Window**: `/keyroll stored` opens a scrollable window to view all cached keystones and roll party keystones
- **Cache Management**: `/keyroll clear` command to manually wipe all stored keystones
- **Post-Dungeon Auto-Capture**: Automatically updates all party keystones 30 seconds after completing a dungeon
- **Party Chat Monitoring**: Now captures keystones when players shift-click them in party chat
- **Enhanced Debug Mode**: Toggle with `/keyroll debug`, seed test keys with `/keyroll debug seed`, clear with `/keyroll debug clear`
- **Expanded Addon Support**: Now supports 11+ keystone-sharing addons including:
  - Astral Keys
  - Keystone Roll-Call (KCLib)
  - Open Raid Library (Details!)
  - Keystone Manager
  - Keystone Announce
- **Battle.net Friend Tracking**: Automatically detects when friends come online and requests their keystones

### Improvements
- **Party-Only Operation**: No longer triggers in raids or follower dungeons
- **Bag Scan Throttling**: Prevents spam from rapid bag updates (2-second cooldown)
- **Smarter Party Detection**: Validates 2-5 real players (excludes NPCs and raids)
- **Better Error Handling**: Uses pcall to suppress "You aren't in a party" errors
- **More Flavor Text**: Added additional roll and win messages
- 30-second cooldown per friend prevents request spam
- Friend requests only sent to players in WoW (not other Blizzard games)
- Multi-addon friend requests (AstralKeys, LibKS, BigWigs, DBM, AngryKeystones, MDT)

### Dungeon Database
- Added Midnight Beta Season 1 dungeons (Magisters' Terrace, Maisara Caverns, etc.)
- Added TWW Season 3 dungeons (Eco-Dome Al'dani, Operation: Floodgate, etc.)
- Maintained backward compatibility with previous dungeon pools

### Bug Fixes
- Fixed "Bag API not ready" errors
- Fixed keystone detection breaking between expansions
- Fixed function reference errors (IsDebug, DebugPrint, GetDungeonName)
- Fixed combat lockdown issues
- Fixed character encoding (— to -)
- Fixed nil safety for missing dungeon names

### Technical Improvements
- AceComm-3.0 integration for reliable addon communication
- Generic addon message listener for unknown formats
- Improved message parsing with multiple fallback patterns
- Better separation of concerns across files
- Comprehensive debug logging system

### Debug Commands
- `/kr debug friends` - Show all cached friend keystones
- `/kr debug globaldb` - Display both guild and friend caches with statistics

For detailed information, see the full README.md
