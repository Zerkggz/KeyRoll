KeyRoll Changelog
Version 3.1.1 (2026-02-06)

GUI Improvements:
New messages in the Guild tab if it is empty.

Technical Changes:
Guild tab now stores per guild instead of all guilds you're in accross your account

Bug Fixes:
Fixed errors caused by trying to access secret values in combat.